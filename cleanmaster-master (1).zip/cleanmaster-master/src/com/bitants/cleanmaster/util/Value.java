package com.bitants.cleanmaster.util;

public class Value 
{
	public static final int  WIDTH = 255;
	public static final int HEIGHT = 60;
	
	public static final int BEGIN_CLEAN = 0x1;
	public static final int END_CLEAN = 0x2;
	public static final int UPDATE = 0x3;
	public static final int UPDATE_VIEW = 0x4;
	
	public static final int V = 10;
}
