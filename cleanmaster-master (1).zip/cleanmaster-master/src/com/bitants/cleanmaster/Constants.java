package com.bitants.cleanmaster;

public class Constants {

	public static final String FILTER = "com.bitants.cleanmaster.Filter";
	
	// TODO
	/**
	 *  改为被监控 total Pss 的 processName
	 *  
	 */
	public static final String PROCESS_NAME = "com.bitants.cleanmaster";
}